
$(document).ready(function()
{
	$("#upload_btn").click(function()
	{
		$("#upload_form").toggle();

	});
});
