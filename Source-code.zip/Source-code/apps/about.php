<?php

include('dbconnect.php');

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>About</title>
    </head>
    <body>

        <?php include_once('../lib/header.php');?>
        <div class="container">
        <div class="row">

        <div class="About">
                            <center>
                  <img style = "width: 50%; padding-bottom: 50px;" src='http://vignette3.wikia.nocookie.net/adventuretimewithfinnandjake/images/f/f3/DANCING_COOKIE.gif/revision/latest?cb=20120702020217'>
                  </center> 
            <div class="col-md-4">
            </div> 
                 </div> 
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4><i class="fa fa-fw fa-gift"></i>Find Local Artists</h4>
                    </div>
                     
                    <div class="panel-body">
                   
                       <p>Our website creates an application for the public to find UNT Student art work to purchase, or to find UNT student artists to do artwork for them. There are a lot of talented artists at UNT, and virtually no convenient place for them to sell or market there services or artwork for the public to buy from, which is a shame. The websit would directly relate to the school, and could benefit both the school and local University artists.</p>
                     </div>            
                </div>
            </div>



    <body>

        <?php include_once('../lib/header.php');?>
<hr>
<div class ="content">
  <div class="FAQ">
          <h1>Contact </h1> 
          <br>
          <div class="well">
            <p><center>Frustrated?<br><br>We're here to help!<br>Please read our FAQ section on this page<br>Feel free to contact us at the provided email address below if your question is not answered.
            <br><br>CookieCodec@CookieCodec.com
            </center>
            </p>
              <h2 style = "text-align: center">Developers</h2> 
              <table style="width:100%">
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                </tr>
                <tr>
                  <td>George Tipton</td>
                  <td>GeorgeTipton@my.unt.edu</td>
                </tr>
                <tr>
                  <td>Alexander Ortegren</td>
                  <td>AlexanderOrtegren@my.unt.edu</td>
                </tr>
              <tr>
                  <td>Andrew Johnston</td>
                  <td>AndrewJohnston@my.unt.edu</td>
                </tr>

              <tr>
                  <td>Zhenghang Liu</td>
                  <td>zhenghangliu@my.unt.edu</td>
                </tr>

              <tr>
                  <td>Tevin Mosley</td>
                  <td>TevinMosley@my.unt.edu</td>
                </tr>
            </table>
          </div>
  </div>
</div>
<hr>

<div class="FAQ">
        <h1>Frequently Asked Questions </h1> 
        <br>
        <div class="well">
        <div class="row">
    <!--    <button data-toggle="collapse" data-target="#demo"><h2>1.How can I upload artwork to my own gallary</h2></button>
          <div id="demo" class="collapse">
              Users inlcude artist and normal users can up load artwork via "upload" in user profile.
          </div>-->
        </div>
        <div class="well">
        <div class="row">    
            <p></div>How can I register for an Artist profile?</div>
            Answer: On the 'Registration' page, when creating a new account, check the checkbox labeled "Artist?"
            </p>
        <div class="well">
        <div class="row">    
            <p></div>How can I edit my profile?</div>
            Answer: When logged in, use your username drop down menu and select 'My Profile'. On your profile page click the 'Edit Profile' button.
            </p>
        <div class="well">
        <div class="row">    
            <p></div>How can I send an Artist a message?</div>
            Answer: From the Gallery, select an image and click the 'Go to Artist' button. On the Artist's profile page, click the 'Send Message' button.
            </p>
        <div class="well">
        <div class="row">    
            <p></div>How can I upload an Image?</div>
            Answer: When logged in, use your username drop down menu and select 'Upload Image'.
            </p>
        </div>
        </div>
        </div>
</div>
</div>
</body>
</html>