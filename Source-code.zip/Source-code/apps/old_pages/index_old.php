<?php


	echo '<title>Bootstrap Installed</title><div style="background: #e9ffed; border: 1px solid #b0dab7; padding: 15px;" align="center" >
	<font size="5" color="#182e7a">Bootstrap is installed successfully.</font><br /><br />
	<font size="4">Bootstrap is a Framework, so doesn\'t have an index page.<br /><br />
	Bootstrap Sleek, intuitive, and powerful front-end framework for faster and easier web development.

Bootstrap was made to not only look and behave great in the latest desktop browsers (as well as IE7!), but in tablet and smartphone browsers via responsive CSS as well. </font></div>';

?>